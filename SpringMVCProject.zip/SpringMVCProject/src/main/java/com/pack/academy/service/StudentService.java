package com.pack.academy.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.academy.dao.Studentdao;
import com.pack.academy.model.Academy;
import com.pack.academy.model.College;
import com.pack.academy.model.Student;

@Service
public class StudentService {
	@Autowired
	Studentdao studentdao;

	@Transactional
	public void saveUser(Student student1, Academy academy) {
		studentdao.saveUser(student1, academy);
	}

	@Transactional
	public College getPlace(Student student) {
		return studentdao.getPlace(student);

	}

	@Transactional
	public List<Student> getAll(int id, int total) {
		return studentdao.getAll(id, total);
	}

	@Transactional
	public List<Student> grtthanper() {
		return studentdao.grtthanper();
	}

}
