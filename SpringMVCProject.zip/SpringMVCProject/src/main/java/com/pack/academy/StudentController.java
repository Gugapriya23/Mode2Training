package com.pack.academy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.pack.academy.model.Academy;
import com.pack.academy.model.College;
import com.pack.academy.model.Student;
import com.pack.academy.service.StudentService;

@Controller
public class StudentController {
	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	@Autowired
	private StudentService studentService;
	ModelMapper mapper = new ModelMapper();
	private HashMap<String, Student> student = null;

	public StudentController() {
		student = new HashMap<String, Student>();
	}

	@ModelAttribute("student")
	public Student createUserModel() {
		return new Student();
	}

	@ModelAttribute("college")
	public College createCollegeModel() {
		return new College();
	}

	@RequestMapping(value = "/student/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		logger.info("Returning studentdetails.jsp page");
		// model.addAttribute("user", new User());
		return "userregn";
	}

	@RequestMapping(value = "/student/add.do", method = RequestMethod.POST)
	public String saveCustomerAction(@ModelAttribute("student") @Validated Student student, BindingResult bindingResult,
			Model model) {

		if (bindingResult.hasErrors()) {
			logger.info("Returning student.jsp page");
			return "userregn";
		}
		logger.info("Returning student_success.jsp page");
		model.addAttribute("student", student);
		Student student1 = mapper.map(student, Student.class);
		Academy academic = mapper.map(student, Academy.class);
		System.out.println(student1.toString());
		this.studentService.saveUser(student1, academic);
		return "success";
	}

	@RequestMapping(value = "/student/findplace", method = RequestMethod.GET)
	public String findStudentplace(HttpServletRequest request, HttpServletResponse response) {
		logger.info("find place");
		// model.addAttribute("student", new Student());
		return "enterUSN";

	}

	@RequestMapping(value = "/student/getplace", method = RequestMethod.POST)
	public String getStudentPlace(@ModelAttribute("student") Student student, Model model) {
		logger.info("Studet get  place page");
		College college = studentService.getPlace(student);
		// System.out.println(college.toString());
		if (college == null) {
			model.addAttribute("message", "Student does not exist,please enter valid USN");
			return "studentnotfound";
		} else {
			model.addAttribute("college", college);
			return "getplace";
		}
	}

	@RequestMapping(value = "/student/getdetails", method = RequestMethod.GET)
	public String getStudentdetails(Model model) {
		logger.info("Returning studentdetailsss.jsp page");
		// model.addAttribute("student", new Student());
		return "page";
	}

	@RequestMapping(value = "/student/getdetails/{pageid}", method = RequestMethod.GET)
	public ModelAndView getdetails(Student student, @PathVariable(value = "pageid") int id)

	{
		int total = 5;
		logger.info("Returning details.jsp");
		if (id == 1) {

		} else {
			id = (id - 1) * total + 1;
		}
		List<Student> list = studentService.getAll(id, total);
		ModelAndView m = new ModelAndView();
		m.addObject("studentlist", list);
		m.setViewName("details");
		return m;
	}

	@RequestMapping(value = "stud/getpercentage", method = RequestMethod.GET)
	@ResponseBody
	public List<Student> listpercentage() {
		return this.studentService.grtthanper();
	}

}