package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account")

public class Account {

	@Column(name = "cust_acc")
	private String cust_acc;
	@Column(name = "balance")
	private float balance;
	@Id
	@Column(name = "cust_id")
	private Integer cust_id;

	public Integer getCust_id() {
		return cust_id;
	}

	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}

	public String getCust_acc() {
		return cust_acc;
	}

	public void setCust_acc(String cust_acc) {
		this.cust_acc = cust_acc;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

}
