package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/transaction/{cust_id}",method=RequestMethod.POST)
	public String Debit(@PathVariable Integer cust_id,@RequestBody Transaction transaction)
	{
		if(transaction.getTransactionType().equals("Debit"))
		{
			return transactionService.saveDeposit(transaction,cust_id);
		}
		else if(transaction.getTransactionType().equals("Credit"))
		{
			return transactionService.saveCredit(transaction,cust_id);
		}
		else
		{
			return "invalid";
		}
		
	}
	
	@RequestMapping(value="/transaction/paging",method=RequestMethod.GET)
	    public ResponseEntity<List<Transaction>> getAllEmployees(
	                        @RequestParam(defaultValue = "1") Integer pageNo,
	                         @RequestParam(defaultValue = "5") Integer pageSize,
	                        @RequestParam(defaultValue = "amount") String sortBy)
	    {
	        List<Transaction> list = transactionService.getAllEmployees(pageNo, pageSize, sortBy);
	 
	        return new ResponseEntity<List<Transaction>>(list, new HttpHeaders(), HttpStatus.OK);
	    }
	
	

}
