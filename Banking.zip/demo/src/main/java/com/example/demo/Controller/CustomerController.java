package com.example.demo.Controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.customerDto.CustomerDtoClass;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;



@RestController
public class CustomerController {
	
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/customer/add")
	public String addCustomer(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
	}
	 
	@PostMapping(value = "/customer/delete/{cust_id}")
	public String deleteCustomer(@PathVariable(value="cust_id") Integer cust_id) {
		return customerService.deleteCustomer(cust_id);
	}
	
    @PatchMapping(value = "/customer/update/{cust_id}")
	public String updateCustomer(@PathVariable Integer cust_id,@RequestBody String email) {
		return customerService.updateCustomer(cust_id,email);
	}
	
	@GetMapping(value = "/customer/getAll")
	public List<CustomerDtoClass> getAllCustomer() {
		return customerService.getAllCustomer();
		
	}
	
	@GetMapping(value = "/customer/get/{cust_id}")
	public Customer getByCustomerId(@PathVariable Integer cust_id) {
		return  customerService.getByCustomerId(cust_id);
		
	}
	

}
