package com.example.demo.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Beneficiary;

@Repository
public interface beniinterface extends CrudRepository<Beneficiary,String> {


	Beneficiary findByIfsccode(String ifsccode);

	
}
