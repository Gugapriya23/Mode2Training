package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.beniinterface;
import com.example.demo.model.Beneficiary;
import com.example.demo.model.Customer;

@Service
public class BeneficiaryService {

	@Autowired
	beniinterface ben;

	// To add a beneficiary
	public String addBeneficiary(Beneficiary beneficiary) {

		beneficiary.setCust_id(beneficiary.getCust_id());
		beneficiary.setBaccNo(beneficiary.getBaccNo());
		beneficiary.setIfsccode(beneficiary.getIfsccode());
		ben.save(beneficiary);
		return "Success";
	}

	// To display a customer details using ifsccode
	public Beneficiary getByBeneficiaryId(String ifsccode) {
		return ben.findByIfsccode(ifsccode);
	}
}
