package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.AccountDao;
import com.example.demo.Dao.TransactionDao;
import com.example.demo.Dao.beniinterface;
import com.example.demo.exception.AccountNotFound;
import com.example.demo.exception.InsufficientBalance;
import com.example.demo.model.Account;
import com.example.demo.model.Beneficiary;
import com.example.demo.model.Transaction;

@Service
public class TransactionService {

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private AccountDao accountDao;

	@Autowired
	private beniinterface beni;

	static PasswordGeneration generation = new PasswordGeneration();

	static Transaction transaction = new Transaction();

	ModelMapper mapper = new ModelMapper();

	// To credit the amount
	public String saveCredit(Transaction transaction, Integer cust_id) {
		List<Account> acc = (List<Account>) accountDao.findAll();
		List<Account> acc1 = (List<Account>) acc.stream()
				.filter(x -> x.getCust_acc().equals(transaction.getCust_accno())).collect(Collectors.toList());
		Account account = accountDao.findById(cust_id).orElse(null);
		float bal1 = account.getBalance();
		float bal2 = acc1.get(0).getBalance();

		// To generate exception handling
		if (account == null || acc1 == null) {
			throw new AccountNotFound("account not found");
		}

		else {
			// To credit the amount to self
			if (account.getCust_acc().equals(transaction.getCust_accno())) {
				System.out.println("self");
				bal1 = bal1 + transaction.getAmount();
				transaction.setCust_id(account.getCust_id());
				transaction.setCust_accno(account.getCust_acc());
				System.out.println(transaction.getCust_accno());
				transaction.setTransactionType("Credit");
				transaction.setDescription("Credited to-----" + transaction.getAmount());
				account.setBalance(bal1);
				System.out.println("insert to transaction table");
				transaction.setTransactionId(generation.getTransactionId());
				transactionDao.save(transaction);
				accountDao.save(account);
				return "credited successfully";
			}
			// To credit the amount to other customers
			else {
				System.out.println("credited with different from to");
				Transaction transaction1 = new Transaction();
				saveDeposit(transaction, cust_id);
				bal2 = bal2 + transaction.getAmount();
				transaction.setCust_id(acc1.get(0).getCust_id());
				System.out.println("Amount:" + transaction.getAmount());
				transaction1.setCust_accno(acc1.get(0).getCust_acc());
				transaction1.setTransactionType("Credit");
				transaction1.setAmount(transaction.getAmount());
				transaction1.setDescription("credited to" + transaction.getAmount() + account.getCust_acc());
				acc1.get(0).setBalance(bal2);
				transaction1.setTransactionId(generation.getTransactionId());
				transactionDao.save(transaction);
				accountDao.save(acc1.get(0));
				return "successfully credited";
			}
		}
	}

	public String saveDeposit(Transaction transaction, Integer cust_id) {

		Account account = accountDao.findById(cust_id).orElse(null);
		float balance = account.getBalance();

		// To generate exception handling
		if (account == null) {
			throw new AccountNotFound("account not found");
		}
		// To debit the amount to the customers
		else {
			if (transaction.getAmount() < account.getBalance()) {
				System.out.println("debit method");
				balance = balance - transaction.getAmount();
				account.setBalance(balance);
				transaction.setCust_id(account.getCust_id());
				transaction.setTransactionType("Debit");
				transaction.setCust_accno(account.getCust_acc());
				System.out.println(account.getCust_acc());
				transaction.setDescription("Debited to-----" + transaction.getAmount());
				transactionDao.save(transaction);
				accountDao.save(account);
				return "debited successfully";
			} else {
				throw new InsufficientBalance("balance is not there");
			}
		}

	}

	// To generate list of all employees transaction
	public List<Transaction> getAllEmployees(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Transaction> pagedResult = transactionDao.findAll(paging);

		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<Transaction>();
		}
	}

}
