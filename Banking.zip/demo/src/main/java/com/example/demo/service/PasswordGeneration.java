package com.example.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class PasswordGeneration {

	String passwd;
	String passwd_shuffle;
	Random random = new Random();
	static Integer transactionid = 1;
	List<String> passwdList = new ArrayList<String>();

	// To generate random password
	public String password() {
		final String CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz";
		final String CHAR_UPPER = CHAR_LOWER.toUpperCase();
		final String NUMBER = "0123456789";
		final String OTHER_CHAR = "@#$*";

		passwd = CHAR_LOWER + CHAR_UPPER + NUMBER + OTHER_CHAR;

		passwd_shuffle = shuffleString(passwd);
		return generateRandomPassword(6);
	}

	private String shuffleString(String string) {
		
		List<String> letters = Arrays.asList(string.split(""));
		Collections.shuffle(letters);
		return letters.stream().collect(Collectors.joining());
	}

	private String generateRandomPassword(int length) {
		
		if (length < 1) {
			throw new IllegalArgumentException();
		}
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			int rndCharAt = random.nextInt(passwd.length());
			char rndChar = passwd.charAt(rndCharAt);
			sb.append(rndChar);
		}
		return sb.toString();
	}

	// To generate random Account number for all customers
	public String accNo() {
		
		int m = (int) Math.pow(10, 9);
		int random = m + new Random().nextInt(9 * m);
		String str = "SBI" + random;
		return str;
	}

	// To generate different Customer_Id for all customers
	public Integer cust_id() {
		int m = (int) Math.pow(10, 3);
		int randm = m + new Random().nextInt(9 * m);
		return randm;
	}

	// To generate a transactionId for every transactions of customers
	public int getTransactionId() {
		return transactionid++;
	}

}
