package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Beneficial")
public class Beneficiary {

	@Column(name = "cust_id")
	private Integer cust_id;
	@Id
	@Column(name = "baccNo")
	private String baccNo;

	public String getBaccNo() {
		return baccNo;
	}

	public void setBaccNo(String baccNo) {
		this.baccNo = baccNo;
	}

	@Column(name = "ifsccode")
	private String ifsccode;

	public Integer getCust_id() {
		return cust_id;
	}

	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

}
