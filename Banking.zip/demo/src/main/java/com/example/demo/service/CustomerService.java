package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.AccountDao;
import com.example.demo.Dao.CustomerDao;
import com.example.demo.customerDto.CustomerDtoClass;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private AccountDao accountDao;

	PasswordGeneration p = new PasswordGeneration();
	Account account = new Account();
	ModelMapper mapper = new ModelMapper();

	@Transactional
	// To add a customer in database with valid user inputs
	public String addCustomer(Customer customer) {

		customer.setCust_passwd(p.password());
		customer.setCust_id(p.cust_id());
		account.setCust_id(customer.getCust_id());
		account.setCust_acc(p.accNo());
		account.setBalance(5000000);

		if (customer.getCust_age() > 21) {
			if (!(String.valueOf(customer.getCust_phoneNo()).length() == 10)) {
				return "Please insert the valid phone number..";
			} else {
				customerDao.save(customer);
				accountDao.save(account);
				return "successfully registered...";
			}
		} else {
			return "you are not eligible";
		}

	}

	// To delete a customer from database
	public String deleteCustomer(Integer cust_id) {
		customerDao.deleteById(cust_id);
		accountDao.deleteById(cust_id);
		return "deleted successfully";
	}

	// To get list of all customers in a database
	List<CustomerDtoClass> list = new ArrayList<CustomerDtoClass>();

	public List<CustomerDtoClass> getAllCustomer() {
		customerDao.findAll().forEach(customer -> convertTo(customer));
		return list;
	}

	private void convertTo(Customer customer) {
		// TODO Auto-generated method stub
		list.add(mapper.map(customer, CustomerDtoClass.class));
	}

	// To update a customer details
	public String updateCustomer(Integer cust_id, String email) {
		Customer customer = customerDao.findById(cust_id).orElse(null);

		if (null != customer) {
			customer.setCust_email(email);
		}
		customerDao.save(customer);
		return "successfully updated";
	}

	// To get a particular customer by their Customer_ID
	public Customer getByCustomerId(Integer cust_id) {
		return customerDao.findById(cust_id).orElse(null);
	}

}
