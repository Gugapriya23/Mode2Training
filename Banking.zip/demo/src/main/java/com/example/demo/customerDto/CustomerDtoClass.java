package com.example.demo.customerDto;

public class CustomerDtoClass {

	private String cust_name;
	private int cust_age;
	private String cust_email;
	private long cust_phoneNo;
	private String job;

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public int getCust_age() {
		return cust_age;
	}

	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public long getCust_phoneNo() {
		return cust_phoneNo;
	}

	public void setCust_phoneNo(long cust_phoneNo) {
		this.cust_phoneNo = cust_phoneNo;
	}

}
