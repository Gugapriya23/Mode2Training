package com.pack.movie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pack.movie.model.Show;

@Repository
public interface ShowDao extends CrudRepository<Show,String>{

	@Query(value="select * from shows s where s.mornshow=?1 or s.aftrnshow=?1 or s.evgshow=?1",nativeQuery=true)
	 List<Show> findByMovieName(String moviename);

	
}
