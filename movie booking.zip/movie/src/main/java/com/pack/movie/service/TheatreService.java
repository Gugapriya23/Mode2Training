package com.pack.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.TheatreDao;
import com.pack.movie.model.Theatre;

@Service
public class TheatreService {

	@Autowired
	private TheatreDao theatredao;

	// To add a movies in theatre
	public String addMovies(Theatre theatre) {
		theatredao.save(theatre);
		return "theatres added";

	}

	// To find the list of movie name
	public List<Theatre> find(String movieName) {
		List<Theatre> p = theatredao.find(movieName);

		return p;

	}

}
