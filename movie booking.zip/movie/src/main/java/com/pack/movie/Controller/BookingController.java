package com.pack.movie.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Booking;
import com.pack.movie.service.BookingService;

@RestController
public class BookingController {

	@Autowired

	BookingService bookingservice;

	@PostMapping(value = "/add/booking")

	public Booking addShowDetails(@RequestParam String moviename, @RequestParam String theatreid,
			@RequestParam String showtime, @RequestParam int userid) {

		return (Booking) bookingservice.addBooking(moviename, theatreid, showtime, userid);

	}

}
