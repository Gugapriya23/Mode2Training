package com.pack.movie.Controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.dto.Showdto;
import com.pack.movie.dto.Theatredto;
import com.pack.movie.model.Movies;
import com.pack.movie.model.Show;
import com.pack.movie.model.Theatre;
import com.pack.movie.service.MoviesService;
import com.pack.movie.service.ShowService;

@RestController
public class ShowController {

	@Autowired
	private ShowService showservice;

	@PostMapping("/add/show")
	public String addMovies(@RequestBody Show show) {
		return showservice.addShow(show);
	}

	@PostMapping("/show/search")
	public String showSearch(@RequestBody Showdto showdto) {
		String str = showservice.checkMovie(showdto);
		return str;
	}

	@GetMapping(value = "/show/list/{moviename}")
	public List<Theatredto> getshow(@PathVariable String moviename) {
		List<Theatredto> p = showservice.showList(moviename);
		return p;

	}

}
