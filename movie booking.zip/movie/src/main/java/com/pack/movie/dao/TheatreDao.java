package com.pack.movie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pack.movie.model.Theatre;

@Repository
public interface TheatreDao extends CrudRepository<Theatre, String> {

	@Query(value = "select * from theatre t where t.theatreid IN (select s.theatreid from shows s where s.mornshow=?1 or s.aftrnshow=?1 or s.evgshow=?1)", nativeQuery = true)
	public List<Theatre> find(String moviename);

}
