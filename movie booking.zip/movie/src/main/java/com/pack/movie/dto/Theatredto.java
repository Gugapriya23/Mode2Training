package com.pack.movie.dto;

public class Theatredto {

	private String theatrename;
	private String place;
	private String mornshow;
	private String aftrnshow;
	private String evgshow;

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getMornshow() {
		return mornshow;
	}

	public void setMornshow(String mornshow) {
		this.mornshow = mornshow;
	}

	public String getAftrnshow() {
		return aftrnshow;
	}

	public void setAftrnshow(String aftrnshow) {
		this.aftrnshow = aftrnshow;
	}

	public String getEvgshow() {
		return evgshow;
	}

	public void setEvgshow(String evgshow) {
		this.evgshow = evgshow;
	}

}
