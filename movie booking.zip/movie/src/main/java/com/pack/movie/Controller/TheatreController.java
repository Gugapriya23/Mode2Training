package com.pack.movie.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Theatre;
import com.pack.movie.service.TheatreService;

@RestController
public class TheatreController {

	@Autowired
	private TheatreService theatreservice;

	@PostMapping("/add/theatre")
	public String addCustomer(@RequestBody Theatre theatre) {
		return theatreservice.addMovies(theatre);
	}

	@GetMapping(value = "/show/get/{moviename}")
	public List<Theatre> getshow(@PathVariable String moviename) {
		List<Theatre> p = theatreservice.find(moviename);
		return p;

	}

}
