package com.pack.movie.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.MoviesDao;
import com.pack.movie.model.Movies;

import springfox.documentation.swagger2.mappers.ModelMapper;

@Service
public class MoviesService {

	@Autowired
	private MoviesDao moviesdao;

	// To add a movies in the database
	@Transactional
	public String addMovies(Movies movies) {
		moviesdao.save(movies);
		return "movies added";
	}

	// To get a list of all movies
	List<Movies> list = new ArrayList<Movies>();

	public Iterable<Movies> getAllMovies() {
		// TODO Auto-generated method stub
		Iterable<Movies> list = moviesdao.findAll();
		return list;
	}

}
