package com.pack.movie.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.MoviesDao;
import com.pack.movie.dao.ShowDao;
import com.pack.movie.dao.TheatreDao;
import com.pack.movie.dto.Showdto;
import com.pack.movie.dto.Theatredto;
import com.pack.movie.exception.MovieNotFound;
import com.pack.movie.model.Movies;
import com.pack.movie.model.Show;
import com.pack.movie.model.Theatre;

@Service
public class ShowService {

	@Autowired
	private ShowDao showdao;
	
	@Autowired
	private TheatreDao theatredao;
	
	//To adding a shows
	@Transactional
	public String addShow(Show show)
	{
		showdao.save(show);
		return "shows added";
	}
	
	//To check whether the movie is running or not
	public String checkMovie(Showdto showdto)
	{
		int flag=0;
		List<Show> list=(List<Show>) showdao.findAll();
		for(Show s:list)
		{
			if(showdto.getShowSearch().equalsIgnoreCase(s.getMornshow()) ||
				showdto.getShowSearch().equalsIgnoreCase(s.getAftrnshow()) ||
				showdto.getShowSearch().equalsIgnoreCase(s.getEvgshow()))
			{
				flag=1;
				return "movie is running !!!";
			}
		}
		if(flag==0)
		{
			throw new MovieNotFound("movie not exists");
		}
		return null;
	}
	
	//To generate list of all shows
	public List<Theatredto> showList(String moviename)
	{
		List<Show> listShow=showdao.findByMovieName(moviename);
		Theatre theatre=new Theatre();
		List<Theatredto> list=new ArrayList();
		
		for(Show show:listShow)
		{
			Theatredto tshowdto=new Theatredto();
			String theatreid=show.getTheatreid();
			theatre =theatredao.findById(theatreid).orElse(null);
			tshowdto.setPlace(theatre.getTheatreplace());
			tshowdto.setTheatrename(theatre.getTheatrename());
			tshowdto.setMornshow(show.getMornshow());
			tshowdto.setAftrnshow(show.getAftrnshow());
			tshowdto.setEvgshow(show.getEvgshow());
			list.add(tshowdto);
		}
		return list;
	}
}
