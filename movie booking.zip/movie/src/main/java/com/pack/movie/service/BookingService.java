package com.pack.movie.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.BookingDao;
import com.pack.movie.dao.ShowDao;
import com.pack.movie.dao.TheatreDao;
import com.pack.movie.model.Booking;
import com.pack.movie.model.Show;
import com.pack.movie.model.Theatre;

@Service
public class BookingService {
	@Autowired

	BookingDao bookingdao;

	@Autowired

	TheatreDao theatredao;

	@Autowired

	ShowDao showdao;

	// To book a ticket
	public Booking addBooking(String movieName, String theatreid, String showTime, int userid) {

		Theatre theatre = theatredao.findById(theatreid).orElse(null);

		Show show = showdao.findById(theatreid).orElse(null);

		Booking b = new Booking();

		b.setUserid(userid);

		b.setShowtime(showTime);

		b.setMoviename(movieName);

		b.setTheatrename(theatre.getTheatrename());

		b.setDate(LocalDate.now());

		return bookingdao.save(b);

	}

}
