package com.pack.movie.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "theatre")
public class Theatre {
	@Id
	private String theatreid;

	private String theatrename;

	private String theatreplace;

	public String getTheatreid() {
		return theatreid;
	}

	public void setTheatreid(String theatreid) {
		this.theatreid = theatreid;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getTheatreplace() {
		return theatreplace;
	}

	public void setTheatreplace(String theatreplace) {
		this.theatreplace = theatreplace;
	}

}
