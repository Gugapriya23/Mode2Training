package com.pack.movie.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Booking;
import com.pack.movie.model.User;
import com.pack.movie.service.BookingService;
import com.pack.movie.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userservice;

	@PostMapping("/add/user")
	public String addBookingMovie(@RequestBody User user) {
		return userservice.addUser(user);
	}
}
