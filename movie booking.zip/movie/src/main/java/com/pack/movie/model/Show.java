package com.pack.movie.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shows")
public class Show {

	private LocalDate date;
	@Id
	private String showid;

	private String theatreid;
	private String mornshow;
	private String aftrnshow;
	private String evgshow;

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getTheatreid() {
		return theatreid;
	}

	public void setTheatreid(String theatreid) {
		this.theatreid = theatreid;
	}

	public String getMornshow() {
		return mornshow;
	}

	public void setMornshow(String mornshow) {
		this.mornshow = mornshow;
	}

	public String getAftrnshow() {
		return aftrnshow;
	}

	public void setAftrnshow(String aftrnshow) {
		this.aftrnshow = aftrnshow;
	}

	public String getEvgshow() {
		return evgshow;
	}

	public void setEvgshow(String evgshow) {
		this.evgshow = evgshow;
	}

	public String getShowid() {
		return showid;
	}

	public void setShowid(String showid) {
		this.showid = showid;
	}

}
