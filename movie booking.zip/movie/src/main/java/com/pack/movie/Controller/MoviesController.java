package com.pack.movie.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.movie.model.Movies;
import com.pack.movie.service.MoviesService;

@RestController
public class MoviesController {

	@Autowired
	private MoviesService moviesservice;

	@PostMapping("/add/movies")
	public String addMovies(@RequestBody Movies movies) {
		return moviesservice.addMovies(movies);
	}

	@GetMapping(value = "/movies/getAll")
	public Iterable<Movies> getAllMovies() {
		return moviesservice.getAllMovies();

	}

}
