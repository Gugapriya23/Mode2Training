package com.pack.movie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.movie.dao.TheatreDao;
import com.pack.movie.dao.UserDao;
import com.pack.movie.model.Theatre;
import com.pack.movie.model.User;

@Service
public class UserService {

	@Autowired
	private UserDao userdao;

	//To add a User
	public String addUser(User user) {
		userdao.save(user);
		return "users added";

	}
}
