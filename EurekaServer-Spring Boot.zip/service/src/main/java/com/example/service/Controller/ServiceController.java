package com.example.service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.Model.CustomerDtoClass;
import com.example.service.Model.Movies;
import com.example.service.Service.Serviceservice;

@RestController
public class ServiceController {

	@Autowired
	Serviceservice service;

	@RequestMapping(value = "/movies/getAll", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<Movies> getMovies() {

		return service.getMovies();
	}

	@RequestMapping(value = "/customer/getAll", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<CustomerDtoClass> getCustomers() {

		return service.getCustomers();
	}
}
