package com.example.service.Service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.service.Model.CustomerDtoClass;
import com.example.service.Model.Movies;

@Service
public class Serviceservice {

	Movies movies = new Movies();

	CustomerDtoClass customerdto = new CustomerDtoClass();

	// To get list of all movies using resttemplate
	public List<Movies> getMovies() {

		RestTemplate restTemplate = new RestTemplate();
		List<Movies> result = restTemplate.getForObject("http://localhost:9090/movies/getAll", List.class);

		return result;
	}

	// To get list of all customers using resttemplate
	public List<CustomerDtoClass> getCustomers() {

		RestTemplate restTemplate = new RestTemplate();
		List<CustomerDtoClass> result = restTemplate.getForObject("http://localhost:9086/customer/getAll", List.class);

		return result;
	}
}
