import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person(18, "Saranya");
		Person p2 = new Person(19, "");
		Person p3 = new Person(42, "uma");
		Person p4 = new Person(53, "mani");

		List<Person> l = new ArrayList<Person>();
		l.add(p1);
		l.add(p2);
		l.add(p3);
		l.add(p4);

		Stream<Person> data = l.stream().filter(p -> p.age % 2 == 0);
		data.forEach(p -> System.out.println(p.name + ": " + p.age));

		Stream<Person> d = l.stream().filter(p -> p.name == " ");
		d.forEach(p -> System.out.println(p.name));

		List<String> l1 = Arrays.asList("mani", "uma", " ", "sangee");
		l1.stream().filter(p -> p.isEmpty()).forEach(System.out::println);

		List<Integer> l2 = Arrays.asList(2, 1, 5, 4, 9, 6);
		l2.stream().filter(p -> (p % 2 == 0)).forEach(System.out::println);

	}

}
