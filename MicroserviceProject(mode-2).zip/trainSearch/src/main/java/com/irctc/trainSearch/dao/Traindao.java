package com.irctc.trainSearch.dao;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.trainSearch.model.Composite;
import com.irctc.trainSearch.model.Train;

@Repository
public interface Traindao extends CrudRepository<Train, Composite> {
	@Query(value = "select * from train t where t.date=?1 and t.source=?2 and t.destination=?3", nativeQuery = true)
	public List<Train> listTrain(LocalDate date, String source, String destination);

	@Query(value = "select * from train t where t.train_id=?1", nativeQuery = true)
	public List<Train> searchByTrainId(String trainId);

	@Modifying
	@Transactional
	@Query(value = "update train t set t.total_seats=?1 where t.train_id=?2 and t.date=?3", nativeQuery = true)
	public int updateSeats(int totalSeats, String trainId, LocalDate date);

}
