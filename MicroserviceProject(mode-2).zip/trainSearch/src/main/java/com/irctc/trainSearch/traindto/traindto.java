package com.irctc.trainSearch.traindto;

public class traindto {
int noOfSeats;

public int getNoOfSeats() {
	return noOfSeats;
}

public void setNoOfSeats(int noOfSeats) {
	this.noOfSeats = noOfSeats;
}

}
