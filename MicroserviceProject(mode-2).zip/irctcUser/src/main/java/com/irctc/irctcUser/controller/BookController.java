package com.irctc.irctcUser.controller;

import java.time.LocalDate;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.irctc.irctcUser.dto.Bookingdto;
import com.irctc.irctcUser.dto.Passengerdto;
import com.irctc.irctcUser.model.Booking;
import com.irctc.irctcUser.model.Passenger;



@RestController
public class BookController {
	@Autowired
	RestTemplate restTemplate;

	@RequestMapping(value = "user/book/trainticket/{userId}/{trainId}/{date}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public Booking ticketBooking(@PathVariable int userId, @PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @RequestBody Bookingdto bookdto) {
		String uri = "http://localhost:8084/book/ticket/" + userId + "/" + trainId + "/" + date;
		return restTemplate.postForObject(uri, bookdto, Booking.class);
	}

	@RequestMapping(value = "user/book/trainpassenger/{userId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public List<Passenger> ticketBooking(@PathVariable int userId, @RequestBody Passenger[] passenger) {
		String uri = "http://localhost:8084/book/train/addPassengerDetails/" + userId;
		return restTemplate.postForObject(uri, passenger, List.class);
	}

	@RequestMapping(value = "user/book/cancelticket/{bookingId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
	public void CancelTicket(@PathVariable int bookingId) {
		String uri = "http://localhost:8084/book/cancel/{bookingId}";

		restTemplate.delete(uri, bookingId);

	}
	
	@RequestMapping(value="user/checkAvailability/ticket/{trainId}/{date}/{noOfSeats}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public String checkAvailability(@PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @PathVariable int noOfSeats)
	{
		String uri="http://localhost:8084/book/checkAvailability/"+trainId+"/"+date+"/"+noOfSeats;
		return restTemplate.getForObject(uri,String.class);
		
	}
	
	@RequestMapping(value = "user/book/train/passenger/{userId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public List<Passenger> passengerBooking(@PathVariable int userId, @RequestBody Passengerdto[] passengersdto) {
		String uri = "http://localhost:8084/book/train/addPassenger/" + userId;
		return restTemplate.postForObject(uri, passengersdto, List.class);
	}


}
