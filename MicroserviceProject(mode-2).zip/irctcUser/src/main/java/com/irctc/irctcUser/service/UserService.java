package com.irctc.irctcUser.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.irctc.irctcUser.dao.Userdao;
import com.irctc.irctcUser.dto.UserRegisterdto;
import com.irctc.irctcUser.dto.Userdto;
import com.irctc.irctcUser.exception.UserNotFound;
import com.irctc.irctcUser.model.Train;
import com.irctc.irctcUser.model.User;

@Service
public class UserService {
	@Autowired
	Userdao userdao;
	@Autowired
	RestTemplate restTemplate;
	User userClass = new User();
	Train train = new Train();
	ModelMapper mapper=new ModelMapper();

	public String addUser(UserRegisterdto userregisterdto) {
		User user=mapper.map( userregisterdto, User.class);
		userdao.save(user);
		return "Successfully Registered in IRCTC with userId:  "+user.getUserId();

	}

	public String login(Userdto userdto) {
		String out = null;
		List<User> userClass = (List<User>) userdao.findAll();
		int flag = 0;
		for (User users : userClass) {

			if (userdto.getPassword().equals(users.getPassword()) && userdto.getUserName().equals(users.getUserName())) {
				out = "You are successfully logged in";
				flag = 1;
				userdto=mapper.map(users, Userdto.class);
				return out;
			}
		}

		if (flag == 0) {
			throw new UserNotFound("Invalid User...Please register!!!");

		}
		
		return null;
	}

}