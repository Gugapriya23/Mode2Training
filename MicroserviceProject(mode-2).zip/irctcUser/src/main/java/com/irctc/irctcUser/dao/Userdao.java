package com.irctc.irctcUser.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.irctcUser.model.User;


@Repository
public interface Userdao extends CrudRepository<User,Integer> {
	@Query("SELECT u FROM User u WHERE u.userName = ?1 and u.password=?2")
	User login(String userName,String password);

}
