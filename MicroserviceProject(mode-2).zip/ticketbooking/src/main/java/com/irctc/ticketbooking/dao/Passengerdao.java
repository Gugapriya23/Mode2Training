package com.irctc.ticketbooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.ticketbooking.model.Passenger;

@Repository
public interface Passengerdao extends CrudRepository<Passenger, Integer> {

}
