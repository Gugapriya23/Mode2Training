package com.irctc.ticketbooking.dto;

public class Passengerdto {
	String passengerName;
	int passsengerAge;

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getPasssengerAge() {
		return passsengerAge;
	}

	public void setPasssengerAge(int passsengerAge) {
		this.passsengerAge = passsengerAge;
	}

	public Passengerdto(String passengerName, int passsengerAge) {
		super();
		this.passengerName = passengerName;
		this.passsengerAge = passsengerAge;
	}

	public Passengerdto() {
		super();
		
	}

}
